﻿namespace SalesWinApp
{
    partial class frmProduct
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dgvDataProduct = new DataGridView();
            btnBack = new Button();
            btnAdd = new Button();
            btnUpdate = new Button();
            btnRemove = new Button();
            btnReset = new Button();
            btnSearch = new Button();
            lbProductID = new Label();
            lbCategoryID = new Label();
            lbUnitPrice = new Label();
            lbProductName = new Label();
            lbWeight = new Label();
            lbSlnStock = new Label();
            txtProductId = new TextBox();
            txtCategoryId = new TextBox();
            txtUnitPrice = new TextBox();
            txtProductName = new TextBox();
            txtWeight = new TextBox();
            txtStock = new TextBox();
            txtSearch = new TextBox();
            ((System.ComponentModel.ISupportInitialize)dgvDataProduct).BeginInit();
            SuspendLayout();
            // 
            // dgvDataProduct
            // 
            dgvDataProduct.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvDataProduct.Location = new Point(12, 199);
            dgvDataProduct.Name = "dgvDataProduct";
            dgvDataProduct.Size = new Size(594, 195);
            dgvDataProduct.TabIndex = 0;
            dgvDataProduct.CellClick += dgvDataProduct_CellClick;
            // 
            // btnBack
            // 
            btnBack.Location = new Point(291, 400);
            btnBack.Name = "btnBack";
            btnBack.Size = new Size(75, 23);
            btnBack.TabIndex = 1;
            btnBack.Text = "Back";
            btnBack.UseVisualStyleBackColor = true;
            btnBack.Click += btnBack_Click;
            // 
            // btnAdd
            // 
            btnAdd.Location = new Point(77, 170);
            btnAdd.Name = "btnAdd";
            btnAdd.Size = new Size(75, 23);
            btnAdd.TabIndex = 2;
            btnAdd.Text = "Add";
            btnAdd.UseVisualStyleBackColor = true;
            btnAdd.Click += btnAdd_Click;
            // 
            // btnUpdate
            // 
            btnUpdate.Location = new Point(205, 170);
            btnUpdate.Name = "btnUpdate";
            btnUpdate.Size = new Size(75, 23);
            btnUpdate.TabIndex = 3;
            btnUpdate.Text = "Update";
            btnUpdate.UseVisualStyleBackColor = true;
            btnUpdate.Click += btnUpdate_Click;
            // 
            // btnRemove
            // 
            btnRemove.Location = new Point(330, 170);
            btnRemove.Name = "btnRemove";
            btnRemove.Size = new Size(75, 23);
            btnRemove.TabIndex = 4;
            btnRemove.Text = "Remove";
            btnRemove.UseVisualStyleBackColor = true;
            btnRemove.Click += btnRemove_Click;
            // 
            // btnReset
            // 
            btnReset.Location = new Point(453, 170);
            btnReset.Name = "btnReset";
            btnReset.Size = new Size(75, 23);
            btnReset.TabIndex = 5;
            btnReset.Text = "Reset";
            btnReset.UseVisualStyleBackColor = true;
            btnReset.Click += btnReset_Click;
            // 
            // btnSearch
            // 
            btnSearch.Location = new Point(496, 86);
            btnSearch.Name = "btnSearch";
            btnSearch.Size = new Size(75, 23);
            btnSearch.TabIndex = 6;
            btnSearch.Text = "Search";
            btnSearch.UseVisualStyleBackColor = true;
            btnSearch.Click += btnSearch_Click;
            // 
            // lbProductID
            // 
            lbProductID.AutoSize = true;
            lbProductID.Location = new Point(59, 35);
            lbProductID.Name = "lbProductID";
            lbProductID.Size = new Size(18, 15);
            lbProductID.TabIndex = 7;
            lbProductID.Text = "ID";
            // 
            // lbCategoryID
            // 
            lbCategoryID.AutoSize = true;
            lbCategoryID.Location = new Point(59, 75);
            lbCategoryID.Name = "lbCategoryID";
            lbCategoryID.Size = new Size(69, 15);
            lbCategoryID.TabIndex = 8;
            lbCategoryID.Text = "Category ID";
            // 
            // lbUnitPrice
            // 
            lbUnitPrice.AutoSize = true;
            lbUnitPrice.Location = new Point(59, 118);
            lbUnitPrice.Name = "lbUnitPrice";
            lbUnitPrice.Size = new Size(33, 15);
            lbUnitPrice.TabIndex = 9;
            lbUnitPrice.Text = "Price";
            // 
            // lbProductName
            // 
            lbProductName.AutoSize = true;
            lbProductName.Location = new Point(291, 35);
            lbProductName.Name = "lbProductName";
            lbProductName.Size = new Size(39, 15);
            lbProductName.TabIndex = 10;
            lbProductName.Text = "Name";
            // 
            // lbWeight
            // 
            lbWeight.AutoSize = true;
            lbWeight.Location = new Point(291, 75);
            lbWeight.Name = "lbWeight";
            lbWeight.Size = new Size(45, 15);
            lbWeight.TabIndex = 11;
            lbWeight.Text = "Weight";
            // 
            // lbSlnStock
            // 
            lbSlnStock.AutoSize = true;
            lbSlnStock.Location = new Point(291, 118);
            lbSlnStock.Name = "lbSlnStock";
            lbSlnStock.Size = new Size(36, 15);
            lbSlnStock.TabIndex = 12;
            lbSlnStock.Text = "Stock";
            // 
            // txtProductId
            // 
            txtProductId.Location = new Point(130, 32);
            txtProductId.Name = "txtProductId";
            txtProductId.Size = new Size(100, 23);
            txtProductId.TabIndex = 13;
            // 
            // txtCategoryId
            // 
            txtCategoryId.Location = new Point(130, 72);
            txtCategoryId.Name = "txtCategoryId";
            txtCategoryId.Size = new Size(100, 23);
            txtCategoryId.TabIndex = 14;
            // 
            // txtUnitPrice
            // 
            txtUnitPrice.Location = new Point(130, 115);
            txtUnitPrice.Name = "txtUnitPrice";
            txtUnitPrice.Size = new Size(100, 23);
            txtUnitPrice.TabIndex = 15;
            // 
            // txtProductName
            // 
            txtProductName.Location = new Point(357, 32);
            txtProductName.Name = "txtProductName";
            txtProductName.Size = new Size(100, 23);
            txtProductName.TabIndex = 16;
            // 
            // txtWeight
            // 
            txtWeight.Location = new Point(357, 72);
            txtWeight.Name = "txtWeight";
            txtWeight.Size = new Size(100, 23);
            txtWeight.TabIndex = 17;
            // 
            // txtStock
            // 
            txtStock.Location = new Point(357, 115);
            txtStock.Name = "txtStock";
            txtStock.Size = new Size(100, 23);
            txtStock.TabIndex = 18;
            // 
            // txtSearch
            // 
            txtSearch.Location = new Point(481, 57);
            txtSearch.Name = "txtSearch";
            txtSearch.Size = new Size(100, 23);
            txtSearch.TabIndex = 19;
            // 
            // frmProduct
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(618, 432);
            Controls.Add(txtSearch);
            Controls.Add(txtStock);
            Controls.Add(txtWeight);
            Controls.Add(txtProductName);
            Controls.Add(txtUnitPrice);
            Controls.Add(txtCategoryId);
            Controls.Add(txtProductId);
            Controls.Add(lbSlnStock);
            Controls.Add(lbWeight);
            Controls.Add(lbProductName);
            Controls.Add(lbUnitPrice);
            Controls.Add(lbCategoryID);
            Controls.Add(lbProductID);
            Controls.Add(btnSearch);
            Controls.Add(btnReset);
            Controls.Add(btnRemove);
            Controls.Add(btnUpdate);
            Controls.Add(btnAdd);
            Controls.Add(btnBack);
            Controls.Add(dgvDataProduct);
            Name = "frmProduct";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Product";
            Load += frmProduct_Load;
            ((System.ComponentModel.ISupportInitialize)dgvDataProduct).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView dgvDataProduct;
        private Button btnBack;
        private Button btnAdd;
        private Button btnUpdate;
        private Button btnRemove;
        private Button btnReset;
        private Button btnSearch;
        private Label lbProductID;
        private Label lbCategoryID;
        private Label lbUnitPrice;
        private Label lbProductName;
        private Label lbWeight;
        private Label lbSlnStock;
        private TextBox txtProductId;
        private TextBox txtCategoryId;
        private TextBox txtUnitPrice;
        private TextBox txtProductName;
        private TextBox txtWeight;
        private TextBox txtStock;
        private TextBox txtSearch;
    }
}