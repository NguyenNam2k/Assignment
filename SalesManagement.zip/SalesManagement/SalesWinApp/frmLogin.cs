﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BusinessObject;
using DataAccess;
using DataAccess.Repository;
using Microsoft.Extensions.Configuration;

namespace SalesWinApp
{
    public partial class frmLogin : Form
    {
        IMemberRepository memberRepository = new MemberRepository();
        BindingSource source;
        public frmLogin()
        {
            InitializeComponent();
        }

        private void frmLogin_Load(object sender, EventArgs e)
        {
            if (Properties.Settings.Default.cbrememberMe.Equals("0"))
            {
                cbrememberMe.Checked = false;
            }
            if (Properties.Settings.Default.email != string.Empty)
            {
                cbrememberMe.Checked = true;
                txtEmail.Text = Properties.Settings.Default.email;
                txtPassword.Text = Properties.Settings.Default.password;
            }
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            if (cbrememberMe.Checked)
            {
                Properties.Settings.Default.email = txtEmail.Text;
                Properties.Settings.Default.password = txtPassword.Text;
                Properties.Settings.Default.cbrememberMe = "1";
                Properties.Settings.Default.Save();
            }
            else
            {
                Properties.Settings.Default.cbrememberMe = "0";
                Properties.Settings.Default.email = "";
                Properties.Settings.Default.password = "";
                Properties.Settings.Default.Save();
            }
            if (Properties.Settings.Default.email != string.Empty)
            {
                txtEmail.Text = Properties.Settings.Default.email;
                txtPassword.Text = Properties.Settings.Default.password;
            }
            if (String.IsNullOrEmpty(txtEmail.Text))
            {
                MessageBox.Show("Enter your username!");
                txtEmail.Select();
                return;

            }
            if (String.IsNullOrEmpty(txtPassword.Text))
            {
                MessageBox.Show("Enter your password!");
                txtPassword.Select();
                return;
            }
            var conf = new ConfigurationBuilder()
                .SetBasePath(Directory.GetCurrentDirectory())
                .AddJsonFile("appsettings.json", true, true)
                .Build();
            string username = conf["User:Email"];
            string password = conf["User:Password"];


            String Email = txtEmail.Text;
            String Password = txtPassword.Text;
            MemberObject member = memberRepository.loginMember(Email, Password);
            if (Email.Equals(username) && Password.Equals(password))
            {
                frmMenu f = new frmMenu(username);
                f.Show();
                this.Hide();
            }
            else if (member != null)
            {
                String accountType = "";
                if (Email.Equals(username))
                {
                    accountType = "admin";
                }
                else
                {
                    accountType = "guess";
                }
                frmMenu f = new frmMenu(Email);
                f.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("This account doesnt not exist!!!");
                return;
            }
        }
    }
}
