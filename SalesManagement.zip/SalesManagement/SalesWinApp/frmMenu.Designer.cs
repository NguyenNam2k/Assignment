﻿namespace SalesWinApp
{
    partial class frmMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnAccount = new Button();
            btnOrder = new Button();
            btnProduct = new Button();
            btnLogout = new Button();
            lbFStore = new Label();
            SuspendLayout();
            // 
            // btnAccount
            // 
            btnAccount.Location = new Point(67, 93);
            btnAccount.Name = "btnAccount";
            btnAccount.Size = new Size(187, 40);
            btnAccount.TabIndex = 0;
            btnAccount.Text = "Account Management";
            btnAccount.UseVisualStyleBackColor = true;
            btnAccount.Click += btnAccount_Click;
            // 
            // btnOrder
            // 
            btnOrder.Location = new Point(67, 165);
            btnOrder.Name = "btnOrder";
            btnOrder.Size = new Size(187, 40);
            btnOrder.TabIndex = 1;
            btnOrder.Text = "Order Management";
            btnOrder.UseVisualStyleBackColor = true;
            btnOrder.Click += btnOrder_Click;
            // 
            // btnProduct
            // 
            btnProduct.Location = new Point(67, 238);
            btnProduct.Name = "btnProduct";
            btnProduct.Size = new Size(187, 40);
            btnProduct.TabIndex = 2;
            btnProduct.Text = "Product Management";
            btnProduct.UseVisualStyleBackColor = true;
            btnProduct.Click += btnProduct_Click;
            // 
            // btnLogout
            // 
            btnLogout.Location = new Point(123, 331);
            btnLogout.Name = "btnLogout";
            btnLogout.Size = new Size(75, 23);
            btnLogout.TabIndex = 3;
            btnLogout.Text = "Logout";
            btnLogout.UseVisualStyleBackColor = true;
            btnLogout.Click += btnLogout_Click;
            // 
            // lbFStore
            // 
            lbFStore.AutoSize = true;
            lbFStore.Font = new Font("Segoe UI", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lbFStore.Location = new Point(126, 30);
            lbFStore.Name = "lbFStore";
            lbFStore.Size = new Size(75, 30);
            lbFStore.TabIndex = 4;
            lbFStore.Text = "FStore";
            // 
            // frmMenu
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(340, 416);
            Controls.Add(lbFStore);
            Controls.Add(btnLogout);
            Controls.Add(btnProduct);
            Controls.Add(btnOrder);
            Controls.Add(btnAccount);
            Name = "frmMenu";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "frmMenu";
            Load += frmMenu_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnAccount;
        private Button btnOrder;
        private Button btnProduct;
        private Button btnLogout;
        private Label lbFStore;
    }
}