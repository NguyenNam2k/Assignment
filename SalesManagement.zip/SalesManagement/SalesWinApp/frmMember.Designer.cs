﻿namespace SalesWinApp
{
    partial class frmMember
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dgvDataMember = new DataGridView();
            btnBack = new Button();
            lbEmail = new Label();
            lbPassword = new Label();
            lbMemberID = new Label();
            lbCompany = new Label();
            lbCity = new Label();
            lbCountry = new Label();
            btnAdd = new Button();
            btnUpdate = new Button();
            btnRemove = new Button();
            txtEmail = new TextBox();
            txtPassword = new TextBox();
            txtMemberId = new TextBox();
            txtCompany = new TextBox();
            txtCity = new TextBox();
            txtCountry = new TextBox();
            ((System.ComponentModel.ISupportInitialize)dgvDataMember).BeginInit();
            SuspendLayout();
            // 
            // dgvDataMember
            // 
            dgvDataMember.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvDataMember.Location = new Point(12, 148);
            dgvDataMember.Name = "dgvDataMember";
            dgvDataMember.Size = new Size(641, 191);
            dgvDataMember.TabIndex = 0;
            dgvDataMember.CellClick += dgvDataMember_CellClick;
            // 
            // btnBack
            // 
            btnBack.Location = new Point(292, 345);
            btnBack.Name = "btnBack";
            btnBack.Size = new Size(75, 23);
            btnBack.TabIndex = 1;
            btnBack.Text = "Back";
            btnBack.UseVisualStyleBackColor = true;
            btnBack.Click += btnBack_Click;
            // 
            // lbEmail
            // 
            lbEmail.AutoSize = true;
            lbEmail.Location = new Point(51, 38);
            lbEmail.Name = "lbEmail";
            lbEmail.Size = new Size(36, 15);
            lbEmail.TabIndex = 2;
            lbEmail.Text = "Email";
            // 
            // lbPassword
            // 
            lbPassword.AutoSize = true;
            lbPassword.Location = new Point(51, 87);
            lbPassword.Name = "lbPassword";
            lbPassword.Size = new Size(57, 15);
            lbPassword.TabIndex = 3;
            lbPassword.Text = "Password";
            // 
            // lbMemberID
            // 
            lbMemberID.AutoSize = true;
            lbMemberID.Location = new Point(261, 38);
            lbMemberID.Name = "lbMemberID";
            lbMemberID.Size = new Size(18, 15);
            lbMemberID.TabIndex = 4;
            lbMemberID.Text = "ID";
            // 
            // lbCompany
            // 
            lbCompany.AutoSize = true;
            lbCompany.Location = new Point(261, 87);
            lbCompany.Name = "lbCompany";
            lbCompany.Size = new Size(59, 15);
            lbCompany.TabIndex = 5;
            lbCompany.Text = "Company";
            // 
            // lbCity
            // 
            lbCity.AutoSize = true;
            lbCity.Location = new Point(462, 38);
            lbCity.Name = "lbCity";
            lbCity.Size = new Size(28, 15);
            lbCity.TabIndex = 6;
            lbCity.Text = "City";
            // 
            // lbCountry
            // 
            lbCountry.AutoSize = true;
            lbCountry.Location = new Point(462, 87);
            lbCountry.Name = "lbCountry";
            lbCountry.Size = new Size(50, 15);
            lbCountry.TabIndex = 7;
            lbCountry.Text = "Country";
            // 
            // btnAdd
            // 
            btnAdd.Location = new Point(120, 119);
            btnAdd.Name = "btnAdd";
            btnAdd.Size = new Size(75, 23);
            btnAdd.TabIndex = 8;
            btnAdd.Text = "Add";
            btnAdd.UseVisualStyleBackColor = true;
            btnAdd.Click += btnAdd_Click;
            // 
            // btnUpdate
            // 
            btnUpdate.Location = new Point(292, 119);
            btnUpdate.Name = "btnUpdate";
            btnUpdate.Size = new Size(75, 23);
            btnUpdate.TabIndex = 9;
            btnUpdate.Text = "Update";
            btnUpdate.UseVisualStyleBackColor = true;
            btnUpdate.Click += btnUpdate_Click;
            // 
            // btnRemove
            // 
            btnRemove.Location = new Point(462, 119);
            btnRemove.Name = "btnRemove";
            btnRemove.Size = new Size(75, 23);
            btnRemove.TabIndex = 10;
            btnRemove.Text = "Remove";
            btnRemove.UseVisualStyleBackColor = true;
            btnRemove.Click += btnRemove_Click;
            // 
            // txtEmail
            // 
            txtEmail.Location = new Point(120, 35);
            txtEmail.Name = "txtEmail";
            txtEmail.Size = new Size(100, 23);
            txtEmail.TabIndex = 11;
            // 
            // txtPassword
            // 
            txtPassword.Location = new Point(120, 84);
            txtPassword.Name = "txtPassword";
            txtPassword.Size = new Size(100, 23);
            txtPassword.TabIndex = 12;
            // 
            // txtMemberId
            // 
            txtMemberId.Location = new Point(326, 35);
            txtMemberId.Name = "txtMemberId";
            txtMemberId.Size = new Size(100, 23);
            txtMemberId.TabIndex = 13;
            // 
            // txtCompany
            // 
            txtCompany.Location = new Point(326, 84);
            txtCompany.Name = "txtCompany";
            txtCompany.Size = new Size(100, 23);
            txtCompany.TabIndex = 14;
            // 
            // txtCity
            // 
            txtCity.Location = new Point(532, 35);
            txtCity.Name = "txtCity";
            txtCity.Size = new Size(100, 23);
            txtCity.TabIndex = 15;
            // 
            // txtCountry
            // 
            txtCountry.Location = new Point(532, 84);
            txtCountry.Name = "txtCountry";
            txtCountry.Size = new Size(100, 23);
            txtCountry.TabIndex = 16;
            // 
            // frmMember
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(665, 374);
            Controls.Add(txtCountry);
            Controls.Add(txtCity);
            Controls.Add(txtCompany);
            Controls.Add(txtMemberId);
            Controls.Add(txtPassword);
            Controls.Add(txtEmail);
            Controls.Add(btnRemove);
            Controls.Add(btnUpdate);
            Controls.Add(btnAdd);
            Controls.Add(lbCountry);
            Controls.Add(lbCity);
            Controls.Add(lbCompany);
            Controls.Add(lbMemberID);
            Controls.Add(lbPassword);
            Controls.Add(lbEmail);
            Controls.Add(btnBack);
            Controls.Add(dgvDataMember);
            Name = "frmMember";
            Text = "Member";
            Load += frmMember_Load;
            ((System.ComponentModel.ISupportInitialize)dgvDataMember).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView dgvDataMember;
        private Button btnBack;
        private Label lbEmail;
        private Label lbPassword;
        private Label lbMemberID;
        private Label lbCompany;
        private Label lbCity;
        private Label lbCountry;
        private Button btnAdd;
        private Button btnUpdate;
        private Button btnRemove;
        private TextBox txtEmail;
        private TextBox txtPassword;
        private TextBox txtMemberId;
        private TextBox txtCompany;
        private TextBox txtCity;
        private TextBox txtCountry;
    }
}