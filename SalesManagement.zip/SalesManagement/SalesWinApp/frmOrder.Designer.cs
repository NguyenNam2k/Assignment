﻿namespace SalesWinApp
{
    partial class frmOrder
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dgvDataOrder = new DataGridView();
            btnAdd = new Button();
            btnUpdate = new Button();
            btnRemove = new Button();
            btnReset = new Button();
            btnStatistics = new Button();
            lbOrderID = new Label();
            lbMemberID = new Label();
            lbFreight = new Label();
            txtOrderID = new TextBox();
            txtMemberID = new NumericUpDown();
            txtFreight = new NumericUpDown();
            btnBack = new Button();
            dateOrder = new DateTimePicker();
            dateRequired = new DateTimePicker();
            dateShipped = new DateTimePicker();
            txtStartDate = new DateTimePicker();
            txtEnddate = new DateTimePicker();
            lbOrderDate = new Label();
            lbRequiredDate = new Label();
            lbShippedDate = new Label();
            lbStartDate = new Label();
            lbEndDate = new Label();
            ((System.ComponentModel.ISupportInitialize)dgvDataOrder).BeginInit();
            ((System.ComponentModel.ISupportInitialize)txtMemberID).BeginInit();
            ((System.ComponentModel.ISupportInitialize)txtFreight).BeginInit();
            SuspendLayout();
            // 
            // dgvDataOrder
            // 
            dgvDataOrder.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvDataOrder.Location = new Point(16, 227);
            dgvDataOrder.Name = "dgvDataOrder";
            dgvDataOrder.Size = new Size(635, 182);
            dgvDataOrder.TabIndex = 0;
            dgvDataOrder.CellClick += dgvDataOrder_CellClick;
            // 
            // btnAdd
            // 
            btnAdd.Location = new Point(47, 137);
            btnAdd.Name = "btnAdd";
            btnAdd.Size = new Size(75, 23);
            btnAdd.TabIndex = 1;
            btnAdd.Text = "Add";
            btnAdd.UseVisualStyleBackColor = true;
            btnAdd.Click += btnAdd_Click;
            // 
            // btnUpdate
            // 
            btnUpdate.Location = new Point(159, 137);
            btnUpdate.Name = "btnUpdate";
            btnUpdate.Size = new Size(75, 23);
            btnUpdate.TabIndex = 2;
            btnUpdate.Text = "Update";
            btnUpdate.UseVisualStyleBackColor = true;
            btnUpdate.Click += btnUpdate_Click;
            // 
            // btnRemove
            // 
            btnRemove.Location = new Point(47, 175);
            btnRemove.Name = "btnRemove";
            btnRemove.Size = new Size(75, 22);
            btnRemove.TabIndex = 3;
            btnRemove.Text = "Remove";
            btnRemove.UseVisualStyleBackColor = true;
            btnRemove.Click += btnRemove_Click;
            // 
            // btnReset
            // 
            btnReset.Location = new Point(159, 175);
            btnReset.Name = "btnReset";
            btnReset.Size = new Size(75, 23);
            btnReset.TabIndex = 4;
            btnReset.Text = "Reset";
            btnReset.UseVisualStyleBackColor = true;
            // 
            // btnStatistics
            // 
            btnStatistics.Location = new Point(431, 198);
            btnStatistics.Name = "btnStatistics";
            btnStatistics.Size = new Size(75, 23);
            btnStatistics.TabIndex = 5;
            btnStatistics.Text = "Statistics";
            btnStatistics.UseVisualStyleBackColor = true;
            btnStatistics.Click += btnStatistics_Click;
            // 
            // lbOrderID
            // 
            lbOrderID.AutoSize = true;
            lbOrderID.Location = new Point(47, 32);
            lbOrderID.Name = "lbOrderID";
            lbOrderID.Size = new Size(51, 15);
            lbOrderID.TabIndex = 6;
            lbOrderID.Text = "Order ID";
            // 
            // lbMemberID
            // 
            lbMemberID.AutoSize = true;
            lbMemberID.Location = new Point(47, 64);
            lbMemberID.Name = "lbMemberID";
            lbMemberID.Size = new Size(66, 15);
            lbMemberID.TabIndex = 7;
            lbMemberID.Text = "Member ID";
            // 
            // lbFreight
            // 
            lbFreight.AutoSize = true;
            lbFreight.Location = new Point(47, 99);
            lbFreight.Name = "lbFreight";
            lbFreight.Size = new Size(44, 15);
            lbFreight.TabIndex = 8;
            lbFreight.Text = "Freight";
            // 
            // txtOrderID
            // 
            txtOrderID.Location = new Point(114, 26);
            txtOrderID.Name = "txtOrderID";
            txtOrderID.Size = new Size(120, 23);
            txtOrderID.TabIndex = 9;
            // 
            // txtMemberID
            // 
            txtMemberID.Location = new Point(114, 62);
            txtMemberID.Name = "txtMemberID";
            txtMemberID.Size = new Size(120, 23);
            txtMemberID.TabIndex = 10;
            // 
            // txtFreight
            // 
            txtFreight.Location = new Point(114, 97);
            txtFreight.Name = "txtFreight";
            txtFreight.Size = new Size(120, 23);
            txtFreight.TabIndex = 11;
            // 
            // btnBack
            // 
            btnBack.Location = new Point(293, 420);
            btnBack.Name = "btnBack";
            btnBack.Size = new Size(75, 23);
            btnBack.TabIndex = 12;
            btnBack.Text = "Back";
            btnBack.UseVisualStyleBackColor = true;
            btnBack.Click += btnBack_Click;
            // 
            // dateOrder
            // 
            dateOrder.Location = new Point(380, 26);
            dateOrder.Name = "dateOrder";
            dateOrder.Size = new Size(200, 23);
            dateOrder.TabIndex = 13;
            // 
            // dateRequired
            // 
            dateRequired.Location = new Point(380, 62);
            dateRequired.Name = "dateRequired";
            dateRequired.Size = new Size(200, 23);
            dateRequired.TabIndex = 14;
            // 
            // dateShipped
            // 
            dateShipped.Location = new Point(380, 99);
            dateShipped.Name = "dateShipped";
            dateShipped.Size = new Size(200, 23);
            dateShipped.TabIndex = 15;
            // 
            // txtStartDate
            // 
            txtStartDate.Location = new Point(380, 135);
            txtStartDate.Name = "txtStartDate";
            txtStartDate.Size = new Size(200, 23);
            txtStartDate.TabIndex = 16;
            // 
            // txtEnddate
            // 
            txtEnddate.Location = new Point(380, 169);
            txtEnddate.Name = "txtEnddate";
            txtEnddate.Size = new Size(200, 23);
            txtEnddate.TabIndex = 17;
            // 
            // lbOrderDate
            // 
            lbOrderDate.AutoSize = true;
            lbOrderDate.Location = new Point(293, 32);
            lbOrderDate.Name = "lbOrderDate";
            lbOrderDate.Size = new Size(64, 15);
            lbOrderDate.TabIndex = 18;
            lbOrderDate.Text = "Order Date";
            // 
            // lbRequiredDate
            // 
            lbRequiredDate.AutoSize = true;
            lbRequiredDate.Location = new Point(293, 64);
            lbRequiredDate.Name = "lbRequiredDate";
            lbRequiredDate.Size = new Size(81, 15);
            lbRequiredDate.TabIndex = 19;
            lbRequiredDate.Text = "Required Date";
            // 
            // lbShippedDate
            // 
            lbShippedDate.AutoSize = true;
            lbShippedDate.Location = new Point(293, 103);
            lbShippedDate.Name = "lbShippedDate";
            lbShippedDate.Size = new Size(77, 15);
            lbShippedDate.TabIndex = 20;
            lbShippedDate.Text = "Shipped Date";
            // 
            // lbStartDate
            // 
            lbStartDate.AutoSize = true;
            lbStartDate.Location = new Point(293, 141);
            lbStartDate.Name = "lbStartDate";
            lbStartDate.Size = new Size(58, 15);
            lbStartDate.TabIndex = 21;
            lbStartDate.Text = "Start Date";
            // 
            // lbEndDate
            // 
            lbEndDate.AutoSize = true;
            lbEndDate.Location = new Point(293, 175);
            lbEndDate.Name = "lbEndDate";
            lbEndDate.Size = new Size(54, 15);
            lbEndDate.TabIndex = 22;
            lbEndDate.Text = "End Date";
            // 
            // frmOrder
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(663, 455);
            Controls.Add(lbEndDate);
            Controls.Add(lbStartDate);
            Controls.Add(lbShippedDate);
            Controls.Add(lbRequiredDate);
            Controls.Add(lbOrderDate);
            Controls.Add(txtEnddate);
            Controls.Add(txtStartDate);
            Controls.Add(dateShipped);
            Controls.Add(dateRequired);
            Controls.Add(dateOrder);
            Controls.Add(btnBack);
            Controls.Add(txtFreight);
            Controls.Add(txtMemberID);
            Controls.Add(txtOrderID);
            Controls.Add(lbFreight);
            Controls.Add(lbMemberID);
            Controls.Add(lbOrderID);
            Controls.Add(btnStatistics);
            Controls.Add(btnReset);
            Controls.Add(btnRemove);
            Controls.Add(btnUpdate);
            Controls.Add(btnAdd);
            Controls.Add(dgvDataOrder);
            Name = "frmOrder";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Order";
            Load += frmOrder_Load;
            ((System.ComponentModel.ISupportInitialize)dgvDataOrder).EndInit();
            ((System.ComponentModel.ISupportInitialize)txtMemberID).EndInit();
            ((System.ComponentModel.ISupportInitialize)txtFreight).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView dgvDataOrder;
        private Button btnAdd;
        private Button btnUpdate;
        private Button btnRemove;
        private Button btnReset;
        private Button btnStatistics;
        private Label lbOrderID;
        private Label lbMemberID;
        private Label lbFreight;
        private TextBox txtOrderID;
        private NumericUpDown txtMemberID;
        private NumericUpDown txtFreight;
        private Button btnBack;
        private DateTimePicker dateOrder;
        private DateTimePicker dateRequired;
        private DateTimePicker dateShipped;
        private DateTimePicker txtStartDate;
        private DateTimePicker txtEnddate;
        private Label lbOrderDate;
        private Label lbRequiredDate;
        private Label lbShippedDate;
        private Label lbStartDate;
        private Label lbEndDate;
    }
}